
// Simple dynamic typing effect
const text = "Trade Smart. Trade Disciplined.";
let index = 0;

function typeEffect() {
    if (index < text.length) {
        document.querySelector("header p").innerHTML += text.charAt(index);
        index++;
        setTimeout(typeEffect, 80);
    }
}

document.querySelector("header p").innerHTML = "";
typeEffect();
